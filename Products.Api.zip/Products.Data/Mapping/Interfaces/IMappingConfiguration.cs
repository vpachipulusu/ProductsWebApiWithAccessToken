﻿using Microsoft.EntityFrameworkCore;

namespace Products.Data.Mapping.Interfaces
{
    public interface IMappingConfiguration
    {
        void ApplyConfiguration(ModelBuilder modelBuilder);
    }
}
