﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Products.Domain.DataModels;

namespace Products.Data.Mapping.Products
{
    public class ProductMap : EntityTypeConfiguration<Product>
    {
        public override void Configure(EntityTypeBuilder<Product> product)
        {
            product.ToTable(nameof(Product));
            product.HasKey(x => x.Id);

            product.Property(x => x.Name).HasMaxLength(100).IsRequired();
            product.Property(x => x.Brand).HasMaxLength(50).IsRequired();

            base.Configure(product);
        }
    }
}
