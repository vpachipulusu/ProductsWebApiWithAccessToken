﻿namespace Products.Domain.Options
{
    public class ConnectionStringsOptions
    {
        public string DefaultConnection { get; set; }
    }
}
