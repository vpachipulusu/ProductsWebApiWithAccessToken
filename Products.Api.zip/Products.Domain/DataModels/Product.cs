﻿namespace Products.Domain.DataModels
{
    public class Product : BaseEntity
    {
        public string Name { get; set; }
        public string Brand { get; set; }
    }
}
