﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Products.Data.Context.Interfaces;

namespace Products.Service.InitializeData
{
    /// <summary>
    /// Initialize db Data
    /// </summary>
    public static class InitializeDataExtensions
    {
        /// <summary>
        /// Database deed data
        /// </summary>
        /// <param name="host">IWebHost</param>
        /// <returns>IWebHost</returns>
        public static IHost SeedData(this IHost host)
        {
            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                var dbContext = services.GetRequiredService<IDbContext>();

                dbContext.EnsureCreated();
            }
            return host;
        }
    }
}
