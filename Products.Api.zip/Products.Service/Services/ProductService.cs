﻿using Products.Data.Repository.Interfaces;
using Products.Domain.DataModels;
using Products.Service.Services.Interfaces;
using System;

namespace Products.Service.Services
{
    public class ProductService : IProductService
    {
        private readonly IRepository<Product> _productRepository;

        public ProductService(IRepository<Product> productRepository)
        {
            _productRepository = productRepository;
        }

        public Product GetProductById(int id)
        {
            if (id == 0)
                throw new ArgumentNullException(nameof(id));

            return _productRepository.GetById(id);
        }

        public void AddProduct(Product product)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(Product));

            _productRepository.Insert(product);
        }

        public void UpdateProduct(Product product)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(Product));

            _productRepository.Update(product);
        }

        public void DeleteProduct(int id)
        {
            if (id == 0)
                throw new ArgumentNullException(nameof(id));

            var post = _productRepository.GetById(id);
            if (post == null)
                throw new Exception($"not found post id:{id}");

            _productRepository.Delete(post);
        }
    }
}
