﻿using Products.Domain.DataModels;

namespace Products.Service.Services.Interfaces
{
    public interface IProductService
    {
        Product GetProductById(int id);
        void AddProduct(Product product);
        void UpdateProduct(Product product);
        void DeleteProduct(int id);
    }
}
