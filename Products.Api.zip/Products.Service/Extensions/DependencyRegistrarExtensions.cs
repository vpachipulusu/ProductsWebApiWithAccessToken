﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Products.Data.Context;
using Products.Data.Context.Interfaces;
using Products.Data.Repository;
using Products.Data.Repository.Interfaces;
using Products.Domain.Options;
using Products.Service.Services;
using Products.Service.Services.Interfaces;

namespace Products.Service.Extensions
{
    public static class DependencyRegistrarExtensions
    {
        /// <summary>
        /// Register dependency injection
        /// </summary>
        /// <param name="services">IServiceCollection</param>
        /// <param name="configuration">IConfiguration</param>
        /// <returns></returns>
        public static IServiceCollection AddDependencyInjection(this IServiceCollection services,
            IConfiguration configuration)
        {
            services
                .Configure<ApplicationOptions>(configuration)
                .Configure<ConnectionStringsOptions>(
                    configuration.GetSection(nameof(ApplicationOptions.ConnectionStrings)));


            services.AddScoped<IProductService, ProductService>();
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddDatabaseContext(configuration);

            return services;
        }

        public static IServiceCollection AddDatabaseContext(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionStrings = configuration.GetSection(nameof(ApplicationOptions.ConnectionStrings)).Get<ConnectionStringsOptions>();
            services.AddDbContext<IDbContext, AppDbContext>(options =>
            {
                options.UseSqlServer(connectionStrings.DefaultConnection);
            });
            ////services.AddSingleton<IDbContext, AppDbContext>();

            return services;
        }
    }
}
