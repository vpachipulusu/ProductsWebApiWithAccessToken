﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Products.Api.Base;
using Products.Domain.DataModels;
using Products.Domain.Models;
using Products.Service.Helpers;
using Products.Service.Services.Interfaces;
using System;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Products.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : CustomBaseController
    {
        protected readonly IProductService ProductService;

        public ProductController(IProductService productService)
        {
            ProductService = productService;
        }

        // GET api/<ProductController>/5
        [Authorize]
        [HttpGet("{id}")]
        public virtual IActionResult Get(int id)
        {
            try
            {
                var entity = ProductService.GetProductById(id);
                if (entity == null)
                    return new NotFoundResult();

                var model = new ProductViewModel()
                {
                    Id = entity.Id,
                    Name = entity.Name,
                    Brand = entity.Brand
                };

                return new ObjectResult(model);
            }
            catch (Exception e)
            {
                base.LogError<ProductController>(e);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        // GET api/<ProductController>
        [Authorize]
        [HttpGet]
        public string Get()
        {
            return "value";
        }

        // POST api/<ProductController>
        [Authorize]
        [HttpPost]
        public virtual IActionResult Post([FromBody] Product product)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var entity = new Product()
                    {
                        Name = product.Name,
                        Brand = product.Brand
                    };

                    ProductService.AddProduct(entity);
                    return Ok();
                }

                return new BadRequestResult();
            }
            catch (Exception e)
            {
                base.LogError<ProductController>(e);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        // PUT api/<ProductController>/5
        [Authorize]
        [HttpPut("{id}")]
        public virtual IActionResult Put(int id, [FromBody] Product product)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var entity = ProductService.GetProductById(id);
                    if (entity == null)
                        return new NotFoundResult();

                    entity.Name = product.Name;
                    entity.Brand = product.Brand;

                    ProductService.AddProduct(entity);
                    return Ok();
                }

                return new BadRequestResult();
            }
            catch (Exception e)
            {
                base.LogError<ProductController>(e);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        // DELETE api/<ProductController>/5
        [Authorize]
        [HttpDelete("{id}")]
        public virtual IActionResult Delete(int id)
        {
            try
            {
                var entity = ProductService.GetProductById(id);
                if (entity == null)
                    return new NotFoundResult();

                ProductService.DeleteProduct(id);

                return Ok();
            }
            catch (Exception e)
            {
                base.LogError<ProductController>(e);
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
